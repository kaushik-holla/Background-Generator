export * from '../dist/ionicons/svg/index.esm';
